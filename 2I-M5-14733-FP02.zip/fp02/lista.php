<?php
$itemlista1=$_POST["item1"];
$itemlista2=$_POST["item2"];
$itemlista3=$_POST["item3"];
$itemlista4=$_POST["item4"];
$itemlista5=$_POST["item5"];
$info=[$itemlista1,$itemlista2,$itemlista3,$itemlista4,$itemlista5];
echo "<ul>";
foreach($info as $a){
echo"<li> $a </li>";
}
echo "<ul>";
$turma = [
  "Ana" => 16,
  "João" => 17,
  "Mara" => 18,
];
echo "<table border ='1'>";
foreach ($turma as $x => $i) {
  echo "<tr>
        <td>$x</td>
        <td>$i</td>
        </td>
   <br>";
}
?> 