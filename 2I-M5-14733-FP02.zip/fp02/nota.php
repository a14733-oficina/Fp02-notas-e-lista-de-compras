<?php
$ava1=$_POST["nota1"];
$ava2=$_POST["nota2"];
$ava3=$_POST["nota3"];
$ava4=$_POST["nota4"];
$ava5=$_POST["nota5"];
$a=[$ava1,$ava2,$ava3,$ava4,$ava5];
$limite =count($a);
$media=(array_sum($a)/$limite);

if($media<10){
    $notaTexto = "Reprovado";
} elseif ($media <= 13) {
    $notaTexto = "Satisfaz";
} elseif ($media <= 17) {
    $notaTexto = "Bom";
}else{
    $notaTexto = "Exceleste";
}
echo "A tua média é ".$media, " e a tua situação é ".$notaTexto;
?>